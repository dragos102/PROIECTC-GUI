#include "domain.h"
#include <string>

using std::to_string;

double oferta::getpret() const noexcept
{
	return pret;

}
string oferta::getdenumire() const
{
	return denumire;
}
string oferta::getdestinatie() const
{
	return destinatie;
}
string oferta::gettip() const
{
	return tip;
}
void oferta::setdenumire(string denumire2)
{
	denumire = denumire2;
}
void oferta::setdestinatie(string destinatie2)
{
	destinatie = destinatie2;
}
void oferta::settip(string tip2)
{
	tip = tip2;
}
void oferta::setpret(double pret2) noexcept
{
	pret = pret2;
}
/*
void DTO::increment()
{
	cnt++;
}

void DTO::set_procent()
{
	procent = cnt;
}

string DTO::get_str()
{
	string output = "Nume:" + nume + " " + "Tip:" + categorie + " " + "Type count:" + to_string(cnt);
	return output;
}*/