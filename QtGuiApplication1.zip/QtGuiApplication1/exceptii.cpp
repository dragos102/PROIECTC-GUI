#include "exceptii.h"

string exceptii::get_message() const
{
	return msg;
}
