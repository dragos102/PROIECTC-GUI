#pragma once
#include <string>
#include "domain.h"
#include "repository.h"

#include <functional>
#include <algorithm>
#include <assert.h>
#include "validator.h"
#include "undo.h"
#include <memory>
#include <vector>
using std::string;
class service
{
private:
	repo& rep;

	std::vector<unique_ptr<ActiuneUndo>> undoActions;
	std::vector<unique_ptr<ActiuneUndocos>> undoActions2;
	repo2& rep2;
	ofertavalidare& val;
public:
	service(repo& rep, repo2& rep2, ofertavalidare& val) noexcept :rep{ rep }, rep2{ rep2 }, val{ val } {

	}


	service(const service& ot) = delete;
	service() = default;

	//aceasta functie adauga o oferta in lista de oferte
	//input denumire,destinatie,tip,pret
	//output lista modificata,fiind adaugat elementul
	int add(string denumire, string destinatie, string tip, double pret);

	//aceasta functie adauga o oferta in lista de oferte din submeniu
	//input denumire
	//output lista modificata,fiind adaugat elementul
	int adaugaresubmeniu(string denumire);

	//aceasta functie goleste lista din submeniu
	//se apeleaza stergerea din repository
	//input lista 
	//output lista goala
	void goliresubmeniu() noexcept;

	void generarealeator1(int nr);
	//aceasta functie sterge un element din lista 
	//se introduc datele de sterge
	//daca se poate se sterge elementul si se afiseaza un mesaj corespunzator
	void del(string denumire, string destinatie, string tip, double pret);


	//aceasta functie returneaza lista de oferte
	const vector <oferta>& getall();

	//functia care cauta un element din lista de oferte
	//input denumire,destinatie,tip,pret
	//output 1 daca exista 0 in caz contrar
	int cautare(string denumire, string destinatie, string tip, double pret);

	//functia care modifica un element din lista de oferte
	//input denumire,destinatie,tip,pret si aceleasi date cu care se modifica elementul din lista
	//output lista modificata
	void modificare(string denumire, string destinatie, string tip, double pret, string denumire1, string destinatie1, string tip1, double pret1);

	/*
	aceasta functie filtreaza lista dupa o anumita denumire
	input denumirea
	output o noua lista care contine doar acela atribut
	*/
	vector<oferta> filtreaza(string denumire);
	/*
	aceasta functie filtreaza lista dupa un anumit pret
	input denumirea
	output o noua lista care contine doar acela atribut
	*/
	vector<oferta> filtreazapret(double pret);

	/*
	//functia care ordoneaza lista dupa destinatie
	//input
	//output lista modificata
	*/
	vector<oferta> ordonaredestinatie();

	/*
	//functia care ordoneaza lista dupa denumire
	//input
	//output lista modificata
	*/
	vector<oferta> ordonaredenumire();
	/*
	//functia care ordoneaza lista dupa tip+pret
	//input
	//output lista modificata
	*/
	vector<oferta>ordonaretippret();

	vector<oferta> filtreaza(function<bool(const oferta&)> fct);

	int allprices();
	vector<oferta> getall2();
	//vector<DTO> statistica();
	void exportacoscvs(string denumire) const;

	void exportacoshtml(string denumire) const;

	void undo();

	void undo2();
};
//acestea sunt functiile de teste
void testadd();
void testmodificare();
void testcautare();
void testsortare();
void testdelete();
void testsortare2();
void testsortare3();
void testfiltrarepret();
void testfiltrare();
void testadaugaresubmeniu();
void testgoliresubmeniu();
void testgenerarealeator();
void testundo();
void testundo2();
void testallprice();
void testExporta();
