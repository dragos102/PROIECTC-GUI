#pragma once
#include <QtWidgets/qwidget.h>
#include "QtGuiApplication1.h"
#include <QtWidgets/QApplication>
#include "QtGuiApplication1.h"
#include <QtWidgets/QApplication>
#include <QtWidgets/qlabel.h>
#include <QtWidgets/qpushbutton.h>
#include <QtWidgets/qboxlayout>
#include <QtWidgets/qlineedit.h>
#include <qtwidgets/qformlayout.h>
#include <QtWidgets/qlistwidget.h>
#include <qmessagebox.h>
#include <vector>
#include "service.h"
#include "domain.h"
#include <qdebug.h>
#include <QRadioButton> 
#include "exceptii.h"
using std::vector;
using std::string;
using std::to_string;

class modify :public QWidget
{
private:
	service& srv;

	QGridLayout* lym = new QGridLayout;
	QListWidget* lsm = new QListWidget;
	QLineEdit* nume = new QLineEdit;
	QLineEdit* destinatie = new QLineEdit;
	QLineEdit* tip = new QLineEdit;
	QLineEdit* pret = new QLineEdit;
	QLineEdit* nume2 = new QLineEdit;
	QLineEdit* destinatie2 = new QLineEdit;
	QLineEdit* tip2 = new QLineEdit;
	QLineEdit* pret2 = new QLineEdit;
	QPushButton* btn1 = new QPushButton("MODIFICA");
public:
	modify(service& o) :srv(o)
	{
		init();
		makeconexiuni();
	}
	void init()
	{
		setLayout(lym);

		auto principal = new QVBoxLayout;
		auto lista = new QFormLayout;
		lista->addRow("nume", nume);
		lista->addRow("destinatie", destinatie);
		lista->addRow("tip", tip);
		lista->addRow("pret", pret);
		principal->addLayout(lista);
		auto second = new QFormLayout;
		lista->addRow("nume nou", nume2);
		lista->addRow("destinatie noua", destinatie2);
		lista->addRow("tip nou", tip2);
		lista->addRow("pret nou", pret2);
		principal->addLayout(second);
		principal->addWidget(btn1);
		lym->addLayout(principal, 1, 1, 0);
	}
	void makeconexiuni()
	{
		QObject::connect(btn1, &QPushButton::clicked, [&]() {
			auto nx = nume->text();
			auto ndest = destinatie->text();
			auto tx = tip->text();
			auto px = pret->text();
			if (srv.cautare(nx.toStdString(), ndest.toStdString(), tx.toStdString(), px.toDouble()) != 1)
			{
				QMessageBox::information(nullptr,"info","elementul dat nu exista!");
				close();
			}
			else
			{
				auto nx2 = nume2->text();
				auto ndest2 = destinatie2->text();
				auto tx2 = tip2->text();
				auto px2 = pret2->text();
				srv.modificare(nx.toStdString(), ndest.toStdString(), tx.toStdString(), px.toDouble(), nx2.toStdString(), ndest2.toStdString(), tx2.toStdString(), px2.toDouble());
				QMessageBox::information(nullptr, "info", "Modificare facuta cu succes!");
				close();
			}
			});
	}
};