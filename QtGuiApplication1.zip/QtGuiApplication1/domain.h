#pragma once
#include <string>
#include <iostream>
using std::string;
using std::cout;
class oferta
{
private:
	string denumire;
	string destinatie;
	string tip;
	double pret;
public:
	//aceasta functie returneaza pretul unei oferte
	double getpret() const noexcept;

	//aceasta functie returneaza denumirea unei oferte
	string getdenumire() const;

	//aceasta functie returneaza destinatia unei oferte
	string getdestinatie() const;

	//aceasta functie returneaza tipul unei oferte
	string gettip() const;

	//aceasta functie seteaza denumirea unei oferte denumire2
	void setdenumire(string denumire2);

	//aceasta functie seteaza destinatia unei oferte destinatie2
	void setdestinatie(string destinatie2);

	//aceasta functie seteaza tipul unei oferte tip2
	void settip(string tip2);

	//aceasta functie seteaza pretul unei oferte pret2
	void setpret(double pret2) noexcept;

	//constructorul
	oferta(string denumire, string dest, string tip, double pr) :denumire{ denumire }, destinatie{ dest }, tip{ tip }, pret{ pr }
	{
	}

};
/*
class DTO {
private:
	string nume;
	string categorie;
	int cnt;
	double procent;
public:
	DTO() = default;
	DTO(string nume, string key) :nume{ nume }, categorie{ key }, cnt{ 1 }, procent{ 0 }{};
	void increment();
	void set_procent();
	string get_str();
};*/