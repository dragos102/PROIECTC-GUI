#pragma once
#include <QtWidgets/qwidget.h>
#include "QtGuiApplication1.h"
#include <QtWidgets/QApplication>
#include "QtGuiApplication1.h"
#include <QtWidgets/QApplication>
#include <QtWidgets/qlabel.h>
#include <QtWidgets/qpushbutton.h>
#include <QtWidgets/qboxlayout>
#include <QtWidgets/qlineedit.h>
#include <qtwidgets/qformlayout.h>
#include <QtWidgets/qlistwidget.h>
#include <qmessagebox.h>
#include <vector>
#include "service.h"
#include "domain.h"
#include <qdebug.h>
#include <QRadioButton> 
#include "cos.h"
#include "exceptii.h"
#include "modifica.h"
using std::vector;
using std::string;
using std::to_string;
class guiafisareui : public QWidget
{
public:
	guiafisareui(service& srv) : srv{srv}
	{
		initgui();
		loaddata();
		initconnect();
		adaugaButoane(srv.getall());
	}

private:
	service& srv;

	QGridLayout* ly = new QGridLayout;
	QListWidget* ls = new QListWidget;
	
	QPushButton* btn1 = new QPushButton{ "&Adaugare" };
	QPushButton* btn2 = new QPushButton{ "&Stergere" };
	QPushButton* btn3 = new QPushButton{ "&CAUTARE" };
	QPushButton* btn4 = new QPushButton{ "&EXIT" };
	QRadioButton* btn5 = new QRadioButton{ "&SORT BY NAME" };
	QRadioButton* btn6 = new QRadioButton("SORT BY DESTINATION");
	QRadioButton* btn7 = new QRadioButton("SORT BY PRICE+TYPE");
	QLineEdit* txtnume = new QLineEdit;
	QLineEdit* txtdest = new QLineEdit;
	QLineEdit* txttip = new QLineEdit;
	QLineEdit* txtpret = new QLineEdit;
	QPushButton* btn8 = new QPushButton{ "&Filtrare pret" };
	QPushButton* btn9 = new QPushButton{ "Filtrare denumire" };
	QPushButton* btn10 = new QPushButton{ "INTRARE COS" };
	QPushButton* btn11 = new QPushButton{ "Valoare totala preturi" };
	QPushButton* btn12 = new QPushButton{ "UNDO" };
	QPushButton* btn13 = new QPushButton{ "MODIFICA" };
	QWidget* btnDyn = new QWidget;
	QVBoxLayout* lyBtnDy = new QVBoxLayout;
	void adaugaButoane(const std::vector<oferta>& oferte)
	{
		while (auto item =lyBtnDy->takeAt(0))
		{
			delete item->widget();
			
		}
		for (const auto& p : oferte)
		{
			auto btn = new QPushButton{ QString::fromStdString(p.getdenumire()) };
			lyBtnDy->addWidget(btn);
			QObject::connect(btn, &QPushButton::clicked, [this,btn,p] () {
				srv.del(p.getdenumire(), p.getdestinatie(), p.gettip(), p.getpret());
				delete btn;
				loaddata();
				});
		}
	}
	void initconnect()
	{
		QObject::connect(ls, &QListWidget::itemSelectionChanged, [&]() {
			QModelIndexList selectedIndexes = this->ls->selectionModel()->selectedIndexes();
			int selectedIndex = selectedIndexes.at(0).row();
			if (selectedIndexes.size()<=0)
			{
				txtnume->setText("");
				txtdest->setText("");
				txtpret->setText("");
				txttip->setText("");
			}
			else
			{
				vector<oferta> t = srv.getall();
				oferta of = t[selectedIndex];
				txtnume->setText(QString::fromStdString(of.getdenumire()));
				txtdest->setText(QString::fromStdString(of.getdestinatie()));
				txttip->setText(QString::fromStdString(of.gettip()));
				double p = of.getpret();
				string q = to_string(p);
				txtpret->setText(QString::fromStdString(q));
			}
			});
		QObject::connect(btn13, &QPushButton::clicked, [&]() {
			auto mod = new modify{ srv };
			mod->show();
			//modify a{ srv };
			//a.show();
			loaddata();
			adaugaButoane(srv.getall());
			});
		QObject::connect(btn12, &QPushButton::clicked, [&]() {
			try {
				srv.undo();
				loaddata();
				
			}
			catch (const exceptii & ex)
			{
				ls->addItem(QString::fromStdString("nu se mai poate face undo"));
			}
			});
		QObject::connect(btn11, &QPushButton::clicked, [&]() {
			double p = srv.allprices();
			string str = to_string(p);
			ls->addItem(QString::fromStdString(str));
			});
		QObject::connect(btn10, &QPushButton::clicked, [&]() {
			auto gui2 = new classcos{ srv };
			gui2->show();
			});
		QObject::connect(btn9, &QPushButton::clicked, [&]() {
			auto pret = txtnume->text();
			if (pret.size() == 0)
			{
				QMessageBox::information(nullptr, "info", "Va rugam sa  introduceti o denumire!!!");
			}
			else {
				vector<oferta> of = srv.filtreaza(pret.toStdString());
				ls->clear();
				for (const auto& numecalat : of)
				{
					double a = numecalat.getpret();
					string str = to_string(a);
					ls->addItem(QString::fromStdString(numecalat.getdenumire() + "-" + numecalat.getdestinatie() + "-" + numecalat.gettip() + "-" + str));
				}
			}
			});
		QObject::connect(btn8, &QPushButton::clicked, [&]() {
			auto pret = txtpret->text();
			if (pret.size() == 0)
			{
				QMessageBox::information(nullptr, "info", "Va rugam sa  introduceti un pret!!!");
			}
			else {
				vector<oferta> of = srv.filtreazapret(pret.toDouble());
				ls->clear();
				for (const auto& numecalat : of)
				{
					double a = numecalat.getpret();
					string str = to_string(a);
					ls->addItem(QString::fromStdString(numecalat.getdenumire() + "-" + numecalat.getdestinatie() + "-" + numecalat.gettip() + "-" + str));
				}
			}
			});
		QObject::connect(btn7, &QRadioButton::clicked, [&]() {
			vector <oferta> allProduct = srv.ordonaretippret();
			ls->clear();
			for (const auto& numecalat : allProduct)
			{
				double a = numecalat.getpret();
				string str = to_string(a);
				ls->addItem(QString::fromStdString(numecalat.getdenumire() + "-" + numecalat.getdestinatie() + "-" + numecalat.gettip() + "-" + str));
			}
			adaugaButoane(allProduct);
			});
		QObject::connect(btn5, &QRadioButton::clicked, [&]() {
			vector <oferta> allProduct = srv.ordonaredenumire();
			ls->clear();
			for (const auto& numecalat : allProduct)
			{
				double a = numecalat.getpret();
				string str = to_string(a);
				ls->addItem(QString::fromStdString(numecalat.getdenumire() + "-" + numecalat.getdestinatie() + "-" + numecalat.gettip() + "-" + str));
			}
			adaugaButoane(allProduct);
			});
		QObject::connect(btn6, &QRadioButton::clicked, [&]() {
				vector <oferta> allProduct = srv.ordonaredestinatie();
				ls->clear();
				for (const auto& numecalat : allProduct)
				{
					double a = numecalat.getpret();
					string str = to_string(a);
					ls->addItem(QString::fromStdString(numecalat.getdenumire() + "-" + numecalat.getdestinatie() + "-" + numecalat.gettip() + "-" + str));
				}
				adaugaButoane(allProduct);
				});
		QObject::connect(btn2, &QPushButton::clicked, [&]() {
			auto nume = txtnume->text();
			auto destinatie = txtdest->text();
			auto tip = txttip->text();
			auto pret = txtpret->text();
			vector <oferta> a = srv.getall();
			srv.del(nume.toStdString(), destinatie.toStdString(), tip.toStdString(), pret.toDouble());
			vector <oferta> b = srv.getall();
			if (a.size() != b.size()) {
				QMessageBox::information(nullptr, "info", "Stergerea a fost realizata cu succes");
				adaugaButoane(b);
			}
			else
			{
				QMessageBox::information(nullptr, "info", "Stergerea nu a putut fi realizata");

			}
			loaddata();
			});
		QObject::connect(btn4, &QPushButton::clicked, [&]() {
			QMessageBox::information(nullptr, "info", "ATI IESIT DIN APLICATIE");
			close();
			});
		QObject::connect(btn1, &QPushButton::clicked, [&]() {
			auto nume = txtnume->text();
			auto destinatie = txtdest->text();
			auto tip = txttip->text();
			auto pret = txtpret->text();
			int t = srv.add(nume.toStdString(), destinatie.toStdString(), tip.toStdString(), pret.toDouble());
			if (t == 0) {
				loaddata();
				adaugaButoane(srv.getall());
			}
			else
			{
				if (t == -1)
				{
					QMessageBox::information(nullptr, "info", "din pacate acest element exista deja in lista");

				}
				if (t == 1)
				{
					QMessageBox::information(nullptr, "info", "denumierea introdusa nu este buna");

				}
				if (t == 2)
				{
					QMessageBox::information(nullptr, "info", "destinatia introdusa nu este buna");

				}
				if (t == 3)
				{
					QMessageBox::information(nullptr, "info", "pretul  introdus nu este bun");

				}
				if (t == 4)
				{
					QMessageBox::information(nullptr, "info", "tipul introdus nu este bun");

				}
				if (t == 5)
				{
					QMessageBox::information(nullptr, "info", "mai multe campuri introduse nu sunt corecte");

				}
			}
			});
		QObject::connect(btn3, &QPushButton::clicked, [&]() {
			auto nume = txtnume->text();
			auto destinatie = txtdest->text();
			auto tip = txttip->text();
			auto pret = txtpret->text();
			int t = srv.cautare(nume.toStdString(), destinatie.toStdString(), tip.toStdString(), pret.toDouble());
			if (t == 1)
			{
				QMessageBox::information(nullptr, "info", "ELEMENTUL CAUTAT EXISTA");

			}
			else
			{
				QMessageBox::information(nullptr, "info", "ELEMENTUL CAUTAT NU EXISTA");

			}
			});
	}
	void loaddata()
	{
		vector <oferta> allProduct = srv.getall();
		ls->clear();
		for (const auto& numecalat : allProduct)
		{
			double a = numecalat.getpret();
			string str = to_string(a);
			QListWidgetItem* dataline = new QListWidgetItem();
			dataline->setText(QString::fromStdString(numecalat.getdenumire() + "-" + numecalat.getdestinatie() + "-" + numecalat.gettip() + "-" + str));
			dataline->setBackgroundColor(Qt::red);
			ls->addItem(dataline);
		}
	}
	void initgui()
	{


		//daca pui	QVBoxLayout -le pune pe verticala
		setLayout(ly);

		//ly->addWidget(ls);
		auto abc = new	QVBoxLayout;
		
		abc->addWidget(ls);
		abc->addWidget(btn5);
		abc->addWidget(btn6);
		abc->addWidget(btn7);
		ly->addLayout(abc, 1, 1, 0);

		auto stgly = new QVBoxLayout;
		auto formly = new QFormLayout;
		formly->addRow("Nume ", txtnume);
		formly->addRow("Destinatie ", txtdest);
		formly->addRow("Tip", txttip);
		formly->addRow("Pret ", txtpret);
		stgly->addLayout(formly);

		auto ly2 = new QHBoxLayout{};
		ly2->addWidget(btn1);
		ly2->addWidget(btn2);
		ly2->addWidget(btn3);
		ly2->addWidget(btn4);
		stgly->addLayout(ly2);
		
		

		auto  filtrari = new QVBoxLayout;
		auto butoane = new QHBoxLayout;
		butoane->addWidget(btn8);
		butoane->addWidget(btn9);
		butoane->addWidget(btn10);
		butoane->addWidget(btn11);
		butoane->addWidget(btn12);
		butoane->addWidget(btn13);
		filtrari->addLayout(butoane);
		ly->addLayout(stgly,1,3,0);
		ly->addLayout(filtrari, 2, 3, 0);
		
		btnDyn->setLayout(lyBtnDy);
		ly->addWidget(btnDyn, 1, 4, 0);
		
	}
};

