#pragma once
#include "domain.h"
#include "repository.h"
class ActiuneUndo {
public:
	virtual void doUndo() = 0;
	//destructorul e virtual pentru a ne asigura ca daca dau delete se apeleaza destructorul din clasa care trebuie
	virtual ~ActiuneUndo() = default;
};
class ActiuneUndocos {
public:
	virtual void doUndo2() = 0;
	//destructorul e virtual pentru a ne asigura ca daca dau delete se apeleaza destructorul din clasa care trebuie
	virtual ~ActiuneUndocos() = default;
};

class UndoAdauga : public ActiuneUndo {
	oferta ofertaAdaugat;
	repo& rep;
public:
	UndoAdauga(repo& rep, const  oferta& p) :rep{ rep }, ofertaAdaugat{ p } {}

	void doUndo() override {
		rep.del(ofertaAdaugat);
	}
};
class UndoAdaugacos : public ActiuneUndocos {
	oferta ofertaAdaugat2;
	repo2& rep2;
public:
	UndoAdaugacos(repo2& rep2, const  oferta& p) noexcept :rep2{ rep2 }, ofertaAdaugat2{ p } {}

	void doUndo2() override {
		rep2.sterge(ofertaAdaugat2);
	}
};
class UndoSterge : public ActiuneUndo {
	oferta ofertaSters;
	repo& rep;
public:
	UndoSterge(repo& rep, const  oferta& p) noexcept :rep{ rep }, ofertaSters{ p } {}
	void doUndo() override {
		rep.adaugare(ofertaSters);
	}
};