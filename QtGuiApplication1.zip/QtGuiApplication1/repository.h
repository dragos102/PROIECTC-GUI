#pragma once
#include <vector>
#include "domain.h"
#include "repository.h"
#include <assert.h>
#include <algorithm>
#include <iostream>
#include <numeric>
#include <random> // std::default_random_engine
#include <chrono> // std::chrono::system_clock

#include <fstream>
using std::vector;
using std::string;
using std::ostream;
class RepoException {
	//Clasa de RepoError
	string msg;
public:
	RepoException(string m) :msg{ m } {}
	string get_message2()const
	{
		return msg;
	}
	friend ostream& operator<<(ostream& out, const RepoException& er);
};
ostream& operator<<(ostream& out, const RepoException& er);
class repo {
public:
	virtual int adaugare(const oferta& d) = 0;
	virtual int cautare(string denumire, string destinatie, string tip, double pret) = 0;

	virtual const vector <oferta>& getall() = 0;

	virtual void modificare(string denumire, string destinatie, string tip, double pret, string denumire1, string destinatie1, string tip1, double pret1) = 0;

	virtual void del(const oferta& o) = 0;
	virtual int allprices() = 0;
	virtual ~repo() {};
};
class repoprincipal :public repo
{
protected:
	vector<oferta> oferte;
public:
	repoprincipal(const repoprincipal& ot) = delete;
	repoprincipal() noexcept = default;
	int adaugare(const oferta& p) override
	{
		int ok = 0;
		auto found = std::find_if(oferte.begin(), oferte.end(), [p](const oferta& pp) {
			return pp.getdenumire() == p.getdenumire() && pp.getdestinatie() == p.getdestinatie() && p.getpret() == pp.getpret() && p.gettip() == pp.gettip();
			});
		if (found != oferte.end()) {
			ok = 1;
		}
		if (ok == 0) {
			oferte.push_back(p);
			return 0;
		}
		else
		{
			return -1;
		}
	}


	int allprices() override
	{
		vector <oferta> a = getall();
		int s = 0;
		for (const auto& p : a)
		{
			s = s + int(p.getpret());
		}
		return s;
	}
	void del(const oferta& o) override
	{
		vector <oferta> a = getall();
		vector<oferta> init;
		init = oferte;
		vector<oferta> dest;
		copy_if(init.begin(), init.end(), back_inserter(dest), [o](const oferta& aux) {
			return aux.getdenumire() != o.getdenumire() || aux.getdestinatie() != o.getdestinatie() || aux.gettip() != o.gettip() || aux.getpret() != o.getpret();
			});
		oferte = dest;
	}
	const vector<oferta>& getall() override
	{
		return oferte;
	}

	int cautare(string denumire, string destinatie, string tip, double pret) override
	{

		auto rez = std::find_if(oferte.begin(), oferte.end(), [denumire, destinatie, tip, pret](const oferta& a) {
			return a.getdenumire() == denumire && a.getdestinatie() == destinatie && a.getpret() == pret && a.gettip() == tip;
			});
		if (rez != oferte.end())
		{
			return 1;
		}
		else
			return 0;
	}

	void modificare(string denumire, string destinatie, string tip, double pret, string denumire1, string destinatie1, string tip1, double pret1) override
	{
		vector<oferta> init;
		init = oferte;
		vector<oferta> dest;
		copy_if(init.begin(), init.end(), back_inserter(dest), [denumire, destinatie, tip, pret](const oferta& aux) {
			return aux.getdenumire() != denumire || aux.getdestinatie() != destinatie || aux.gettip() != tip || aux.getpret() != pret;
			});
		oferta o{ denumire1,destinatie1,tip1,pret1 };
		dest.push_back(o);
		oferte = dest;
	}

};



class repo2
{
private:
	vector <oferta> of;
public:
	repo2() = default;
	repo2(const repo2& ot) = delete;
	~repo2() = default;

	//functia care adauga in lista un element,lista din submeniu
	//input o oferta
	//output lista modificata
	int adaugare(const oferta& of);

	void goliresubmeniu() noexcept;

	vector<oferta> getallsubmeniu();
	void add2(oferta o);

	void sterge(const oferta& p);

	void exportacoscvs1(const string& denumire);
	void exportacoshtml1(const string& denumire);
};

class repofile :public repoprincipal
{
	string fname;
	void loadfromfile();
	void writetofile();
public:
	repofile(string fname) :repoprincipal(), fname{ fname }{
		loadfromfile();//incarcam datele din fisier
	}
	~repofile() = default;
	int adaugare(const oferta& d) override
	{
		int const t = repoprincipal::adaugare(d);
		writetofile();
		return t;
	}
	void del(const oferta& o) override
	{
		repoprincipal::del(o);
		writetofile();
	}
	const vector <oferta>& getall()  override
	{
		return repoprincipal::getall();
	}
	int cautare(string denumire, string destinatie, string tip, double pret) override
	{
		return repoprincipal::cautare(denumire, destinatie, tip, pret);

	}
	void modificare(string denumire, string destinatie, string tip, double pret, string denumire1, string destinatie1, string tip1, double pret1) override
	{
		repoprincipal::modificare(denumire, destinatie, tip, pret, denumire1, destinatie1, tip1, pret1);
		writetofile();
	}
	int allprices() override
	{
		return repoprincipal::allprices();
	}
};

void test_repo();
void testFileRepo();