#include <QtWidgets/qwidget.h>
#include "QtGuiApplication1.h"
#include <QtWidgets/QApplication>
#include "QtGuiApplication1.h"
#include <QtWidgets/QApplication>
#include <QtWidgets/qlabel.h>
#include <QtWidgets/qpushbutton.h>
#include <QtWidgets/qboxlayout>
#include <QtWidgets/qlineedit.h>
#include <qtwidgets/qformlayout.h>
#include <QtWidgets/qlistwidget.h>
#include <qmessagebox.h>
#include <vector>
#include "service.h"
#include "domain.h"
#include <qdebug.h>
#include <QRadioButton> 
class classcos :public QWidget
{
private:
	service& srv;
	QGridLayout* lyc = new QGridLayout;
	QListWidget* lsc = new QListWidget;
	QPushButton* btn1 = new QPushButton("Adaugare in cos dupa nume");
	QPushButton* btn2 = new QPushButton("Golire lista cosului");
	QPushButton* btn3 = new QPushButton("Generare lista aleator");
	QPushButton* btn4 = new QPushButton("Salvare in fisier CVS");
	QPushButton* btn5 = new QPushButton("Salvare in fisier HTML");
	QPushButton* btn6 = new QPushButton("UNDO");
	QPushButton* btn7 = new QPushButton("Exit");
	QLineEdit* nume = new QLineEdit;
	QLineEdit* numar = new QLineEdit;
	
	void initconect()
	{
		QObject::connect(btn1, &QPushButton::clicked, [&]() {
			auto nx = nume->text();
			srv.adaugaresubmeniu(nx.toStdString());
			load();
			});
		QObject::connect(btn2, &QPushButton::clicked, [&]() {
			srv.goliresubmeniu();
			load();
			});
		QObject::connect(btn3, &QPushButton::clicked, [&]() {
			auto nr = numar->text();
			int nra = nr.toInt();
			srv.generarealeator1(nra);
			load();
			});
		QObject::connect(btn4, &QPushButton::clicked, [&]() {
			auto numex = nume->text();
			srv.exportacoscvs(numex.toStdString());
			});
		QObject::connect(btn5, &QPushButton::clicked, [&]() {
			auto numex = nume->text();
			srv.exportacoshtml(numex.toStdString());
			});
		QObject::connect(btn6, &QPushButton::clicked, [&]() {
			srv.undo2();
			load();
			});
		QObject::connect(btn7, &QPushButton::clicked, [&]() {
			QMessageBox::information(nullptr, "info ", "Acum iesiti din acest submeniu!");
			close();
		});
	}
public:
	classcos(service& srv) : srv{ srv }
	{
		init();
		load();
		initconect();
	}
	
	void load()
	{
		vector <oferta> allProduct = srv.getall2();
		lsc->clear();
		for (const auto& numecalat : allProduct)
		{
			double a = numecalat.getpret();
			string str = to_string(a);
			lsc->addItem(QString::fromStdString(numecalat.getdenumire() + "-" + numecalat.getdestinatie() + "-" + numecalat.gettip() + "-" + str));
		}
	}
	void init()
	{
		setLayout(lyc);
		auto prim = new QVBoxLayout;

		auto first = new QHBoxLayout;
		first->addWidget(lsc);
		lyc->addLayout(first, 1, 1, 0);

		auto numele = new QFormLayout;
		numele->addRow("nume: ",nume);
		numele->addRow("numar: ", numar);
		prim->addLayout(numele);
		lyc->addLayout(prim, 2, 1, 0);
		auto second = new QVBoxLayout;
		second->addWidget(btn1);
		second->addWidget(btn2);
		second->addWidget(btn3);
		second->addWidget(btn4);
		second->addWidget(btn5);
		second->addWidget(btn6);
		second->addWidget(btn7);
		lyc->addLayout(second, 1, 3, 0);


	}
};