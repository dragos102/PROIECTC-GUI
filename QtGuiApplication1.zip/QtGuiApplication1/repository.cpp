#include "repository.h"
#include <assert.h>
#include <algorithm>
#include <iostream>
#include <numeric>
#include <random> // std::default_random_engine
#include <chrono> // std::chrono::system_clock

#include <fstream>

void repo2::add2(oferta o)
{
	of.push_back(o);
}
void repo2::sterge(const oferta& o)
{
	vector<oferta> init;
	init = of;
	vector<oferta> dest;
	copy_if(init.begin(), init.end(), back_inserter(dest), [o](const oferta& aux) {
		return aux.getdenumire() != o.getdenumire() || aux.getdestinatie() != o.getdestinatie() || aux.gettip() != o.gettip() || aux.getpret() != o.getpret();
		});
	of = dest;
}
int repo2::adaugare(const oferta& p)
{
	int ok = 0;
	auto found = std::find_if(of.begin(), of.end(), [p](const oferta& pp) {
		return pp.getdenumire() == p.getdenumire() && pp.getdestinatie() == p.getdestinatie() && p.getpret() == pp.getpret() && p.gettip() == pp.gettip();
		});
	if (found != of.end()) {
		ok = 1;
	}
	if (ok == 0) {
		of.push_back(p);
		return 0;
	}
	else
	{
		return -1;
	}
}
void repo2::goliresubmeniu() noexcept
{
	of.clear();
}
vector<oferta> repo2::getallsubmeniu()
{
	return of;
}

void test_repo()
{
	repoprincipal rep;
	oferta a{ "a","a","a",10 };
	rep.adaugare(a);
	auto of = rep.getall();
	assert(of.size() == 1);
	assert(rep.adaugare(a) == -1);
}
void repo2::exportacoscvs1(const string& denumire)
{
	std::ofstream out(denumire, std::ios::trunc);
	if (!out.is_open())
	{
		throw ("nu se poate deschide");
	}
	for (const auto& p : of) {
		out << p.getdenumire() << ",";
		out << p.getdestinatie() << ",";
		out << p.gettip() << ",";
		out << p.getpret() << std::endl;
	}
	out.close();
}
void repo2::exportacoshtml1(const string& denumire)
{
	std::ofstream out(denumire, std::ios::trunc);
	if (!out.is_open()) {
		throw ("Unable to open file:");
	}
	out << "<html><body>" << std::endl;
	out << "<table border=\"1\" style=\"width:100 % \">" << std::endl;
	for (const auto& p : of) {
		out << "<tr>" << std::endl;
		out << "<td>" << p.getdenumire() << "</td>" << std::endl;
		out << "<td>" << p.getdestinatie() << "</td>" << std::endl;
		out << "<td>" << p.gettip() << "</td>" << std::endl;
		out << "<td>" << p.getpret() << "</td>" << std::endl;
		out << "</tr>" << std::endl;
	}
	out << "</table>" << std::endl;
	out << "</body></html>" << std::endl;
	out.close();
}
void repofile::loadfromfile()
{
	std::ifstream in(fname);
	if (!in.is_open()) { //verify if the stream is opened		
		cout << "nu merge";
	}
	while (!in.eof()) {
		std::string denumire;
		in >> denumire;

		std::string destinatie;
		in >> destinatie;

		std::string tip;
		in >> tip;

		double price;
		in >> price;
		if (in.eof()) {	//nu am reusit sa citesc numarul
			break;
		}
		oferta p{ denumire, destinatie,tip, price };
		repoprincipal::adaugare(p);
		if (in.eof())
			break;
	}
	in.close();
}
void repofile::writetofile()
{
	std::ofstream out(fname);
	if (!out.is_open()) { //verify if the stream is opened
		throw ("Unable to open file:");

	}

	for (const auto& p : getall()) {
		out << p.getdenumire();
		out << std::endl;
		out << p.getdestinatie();
		out << std::endl;
		out << p.gettip();
		out << std::endl;
		out << p.getpret();
		out << std::endl;
	}
	out.close();
}

void testFileRepo() {
	std::ofstream out("testPets.txt", std::ios::trunc);
	out.close();//creez un fisier gol
	repofile repF{ "testPets.txt" };
	repF.adaugare(oferta{ "aaa","bbb","ccc",12 });

	repofile repF2{ "testPets.txt" };
	auto p = repF2.cautare("aaa", "bbb", "ccc", 12);
	assert(p == 1);
	repF2.del(oferta{ "aaa","bbb","ccc",12 });
	assert(repF2.getall().size() == 0);
	repofile repF3{ "testPets.txt" };
	assert(repF3.getall().size() == 0);



}
