#include "validator.h"
#include "domain.h"
#include <sstream>

using std::stringstream;
int ofertavalidare::validare(const oferta& o)
{
	int ok = 0;
	int a = 0, b = 0, c = 0, d = 0;
	if (o.getdenumire().size() == 0)
	{
		a = 1;

	}
	string t = o.getdenumire();
	for (size_t i = 0; i < t.size(); i++)
	{
		if (isdigit(t.at(i)))
			a = 1;
	}

	if (o.getdestinatie().size() == 0) b = 1;
	t = o.getdestinatie();
	for (size_t i = 0; i < t.size(); i++)
	{
		if (isdigit(t.at(i)))
			b = 1;
	}
	/*if (isdigit(atoi(o.getdestinatie().c_str())))
		b = 1;*/
	if (o.getpret() < 0) c = 1;

	if (o.gettip().size() == 0) d = 1;
	/*if (isdigit(atoi(o.gettip().c_str())))
		d = 1;*/
	t = o.gettip();
	for (size_t i = 0; i < t.size(); i++)
	{
		if (isdigit(t.at(i)))
			d = 1;
	}
	if (a == 0 && b == 0 && c == 0 && d == 0)
		return 0;
	ok = a + b + c + d;
	if (ok > 1)
		return 5;
	else {
		if (a == 1)
			return 1;
		else {
			if (b == 1)
				return 2;
			else {
				if (c == 1)
					return 3;
				else {
					return 4;
				}
			}
		}
	}

}
