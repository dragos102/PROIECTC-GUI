#include "service.h"
#include <assert.h>
#include "domain.h"
#include <functional>
#include <algorithm>
#include <map>
#include <iostream>
#include <random> // std::default_random_engine
#include <chrono> // std::chrono::system_clock
#include "undo.h"
#include <memory>
#include "exceptii.h"
using namespace std;
int service::add(string denumire, string destinatie, string tip, double pret)
{
	oferta o{ denumire,destinatie,tip,pret };
	if (val.validare(o) == 0)
	{

		undoActions.push_back(std::make_unique<UndoAdauga>(rep, o));
		return rep.adaugare(o);
	}

	else
	{
		if (val.validare(o) == 1)
			return 1;
		else {
			if (val.validare(o) == 2)
				return 2;
			else {
				if (val.validare(o) == 3)
					return 3;
				else {
					if (val.validare(o) == 4)
						return 4;
					else
					{
						return 5;
					}
				}
			}
		}
	}
}
void service::undo()
{
	if (undoActions.empty()) {
		throw exceptii("Nu mai exista operatii");
	}
	undoActions.back()->doUndo();
	undoActions.pop_back();
}
void service::undo2()
{
	if (undoActions2.empty())
	{
		throw exceptii("Nu mai exista operatii");
	}
	undoActions2.back()->doUndo2();
	undoActions2.pop_back();
}
int service::adaugaresubmeniu(string denumire)
{
	oferta o{ denumire,"","",0 };
	undoActions2.push_back(std::make_unique<UndoAdaugacos>(rep2, o));
	return rep2.adaugare(o);
}
void service::goliresubmeniu() noexcept
{
	rep2.goliresubmeniu();
}
void service::generarealeator1(int nr)
{
	vector<oferta> copie;
	copie = rep.getall();
	while (nr > 0)
	{
		std::mt19937 mt{ std::random_device{}() };
		std::uniform_int_distribution<> const dist(0, copie.size() - 1);
		const int rndNr = dist(mt);// numar aleator intre [0,size-1]

		oferta q = copie.at(rndNr);
		//undoActions2.push_back(std::make_unique<UndoAdaugacos>(rep2, q));
		rep2.add2(q);

		//auto seed = std::chrono::system_clock::now().time_since_epoch().count();
		//std::shuffle(copie.begin(), copie.end(), std::default_random_engine(seed)); //amesteca vectorul v
		nr--;
	}
}
vector<oferta> service::getall2()
{
	return rep2.getallsubmeniu();
}
void service::del(string denumire, string destinatie, string tip, double pret)
{
	oferta o{ denumire,destinatie,tip,pret };
	undoActions.push_back(std::make_unique<UndoSterge>(rep, o));
	return rep.del(o);
}
const vector<oferta>& service::getall()
{
	return rep.getall();
}

int service::allprices()
{
	return rep.allprices();
}

int service::cautare(string denumire, string destinatie, string tip, double pret)
{
	return rep.cautare(denumire, destinatie, tip, pret);
}

void service::modificare(string denumire, string destinatie, string tip, double pret, string denumire1, string destinatie1, string tip1, double pret1)
{
	return rep.modificare(denumire, destinatie, tip, pret, denumire1, destinatie1, tip1, pret1);
}

void service::exportacoscvs(string denumire) const
{
	rep2.exportacoscvs1(denumire);
}
void service::exportacoshtml(string denumire) const
{
	rep2.exportacoshtml1(denumire);
}
vector<oferta> service::filtreaza(string denumire)
{
	vector<oferta> rez;
	/*
	for (const auto& of : rep.getall()) {

		if (of.getdenumire()==denumire)
		{
			rez.push_back(of);
		}
	}
	return rez;*/
	vector<oferta> a = rep.getall();
	std::copy_if(a.begin(), a.end(), back_inserter(rez), [denumire](const oferta& a) {
		return a.getdenumire() == denumire;
		});
	return rez;
}
vector<oferta> service::filtreazapret(double pret)
{
	/*MyLista<oferta> rez;
	for (const auto& of : rep.getall()) {

		if (of.getpret() == pret)
		{
			rez.push_back(of);
		}
	}
	return rez;

	return filtreaza ([pret](const oferta& p)
		{
			return p.getpret() == pret;
		}) ;
		*/
	vector<oferta> rez;
	vector<oferta> a = rep.getall();
	std::copy_if(a.begin(), a.end(), back_inserter(rez), [pret](const oferta& a) noexcept {
		return a.getpret() == pret;
		});
	return rez;
}


vector<oferta> service::ordonaredestinatie() {
	vector<oferta> v{ rep.getall() };//fac o copie	
	/*for (size_t i = 0; i < v.size(); i++) {
		for (size_t j = i + 1; j < v.size(); j++) {
			if (v[i].getdestinatie()> v[j].getdestinatie())
			{
				//interschimbam
				oferta aux = v[i];
				v[i] = v[j];
				v[j] = aux;
			}
		}
	}*/
	std::sort(v.begin(), v.end(), [](const oferta& a, const oferta& b) {
		return a.getdestinatie() < b.getdestinatie();
		});
	return v;

}
vector<oferta> service::ordonaredenumire() {
	vector<oferta> v{ rep.getall() };//fac o copie	
	/*
	for (size_t i = 0; i < v.size(); i++) {
		for (size_t j = i + 1; j < v.size(); j++) {
			if (v[i].getdenumire() > v[j].getdenumire())
			{
				//interschimbam
				oferta aux = v[i];
				v[i] = v[j];
				v[j] = aux;
			}
		}
	}*/
	std::sort(v.begin(), v.end(), [](const oferta& a, const oferta& b) {
		return a.getdenumire() < b.getdenumire();
		});
	return v;
}
/*
vector<oferta>  service:: filtreaza(function<bool(const oferta&)> fct) {
	vector<oferta> rez;
	for (const auto& pet : rep.getall()) {
		if (fct(pet)) {
			rez.push_back(pet);
		}
	}
	return rez;
}
*/

vector<oferta> service::ordonaretippret() {
	vector<oferta> v{ rep.getall() };//fac o copie	
	/*
	for (size_t i = 0; i < v.size(); i++) {
		for (size_t j = i + 1; j < v.size(); j++) {
			if (v[i].gettip() > v[j].gettip())
			{
				//interschimbam
				oferta aux = v[i];
				v[i] = v[j];
				v[j] = aux;
			}
			else
			{
				if (v[i].gettip() == v[j].gettip())
				{
					if (v[i].getpret() > v[j].getpret()) {
						//interschimbam
						oferta aux = v[i];
						v[i] = v[j];
						v[j] = aux;
					}
				}
			}
		}
	}*/
	std::sort(v.begin(), v.end(), [](const oferta& a, const oferta& b) {
		if (a.getdenumire() < b.getdenumire())
		{
			return a.getdenumire() < b.getdenumire();
		}
		else
		{
			if (a.getdenumire() == b.getdenumire())
			{
				return a.getpret() < b.getpret();
			}
			return a.getdenumire() < b.getdenumire();
		}
		});
	return v;
}
void testfiltrarepret()
{
	repoprincipal rep;
	repo2 rep2;
	ofertavalidare val;
	service srv{ rep ,rep2,val };
	srv.add("b", "b", "b", 100);
	srv.add("a", "a", "a", 100);

	vector <oferta> a;
	a = srv.filtreazapret(100);
	assert(a.size() == 2);

	srv.add("c", "c", "c", 10);
	a = srv.filtreazapret(100);
	assert(a.size() == 2);
	a = srv.filtreazapret(10);
	assert(a.size() == 1);
}
void testfiltrare()
{
	repoprincipal rep;
	repo2 rep2;
	ofertavalidare val;
	service srv{ rep,rep2 ,val };
	srv.add("b", "b", "b", 100);
	srv.add("a", "a", "a", 100);

	vector <oferta> a;
	a = srv.filtreaza("a");
	assert(a.size() == 1);

	srv.add("c", "a", "c", 10);
	a = srv.filtreaza("b");
	assert(a.size() == 1);
	a = srv.filtreaza("a");
	assert(a.size() == 1);
}
void testadd()
{
	repoprincipal rep;
	repo2 rep2;
	ofertavalidare val;
	service srv{ rep,rep2 ,val };
	srv.add("a", "a", "a", 100);
	auto ofer = srv.getall();
	assert(ofer.size() == 1);
	assert(srv.add("1", "a", "a", 20) == 1);
	assert(srv.add("", "a", "a", 20) == 1);

	assert(srv.add("a", "1", "a", 20) == 2);
	assert(srv.add("a", "a", "1", 20) == 4);
	assert(srv.add("a", "a", "a", -20) == 3);
	assert(srv.add("3", "4", "a", -20) == 5);
	assert(srv.add("a", "a", "a", 100) == -1);
	assert(srv.add("b", "b", "b", 200) == 0);

}
void testmodificare()
{
	repoprincipal rep;
	repo2 rep2;
	ofertavalidare val;
	service srv{ rep,rep2 ,val };
	srv.add("a", "a", "a", 100);
	srv.add("b", "b", "b", 100);
	srv.modificare("b", "b", "b", 100, "c", "c", "c", 10);
	auto ofer = srv.getall();
	assert(ofer.size() == 2);
}
void testcautare()
{
	repoprincipal rep;
	repo2 rep2;
	ofertavalidare val;
	service srv{ rep,rep2 ,val };
	srv.add("a", "a", "a", 100);
	assert(srv.cautare("a", "a", "a", 100) == 1);

	srv.add("a", "b", "b", 100);
	srv.add("a", "a", "c", 100);

	assert(srv.cautare("a", "b", "a", 100) == 0);
	assert(srv.cautare("a", "a", "c", 100) == 1);
}
void testsortare()
{
	repoprincipal rep;
	repo2 rep2;
	ofertavalidare val;
	service srv{ rep,rep2 ,val };
	srv.add("b", "b", "b", 100);
	srv.add("a", "a", "a", 100);

	vector <oferta> a;
	a = srv.ordonaredestinatie();
	assert(a.at(0).getdenumire() == "a");

}
void testsortare2()
{
	repoprincipal rep;
	repo2 rep2;
	ofertavalidare val;
	service srv{ rep,rep2 ,val };
	srv.add("b", "b", "b", 100);
	srv.add("a", "a", "a", 100);
	vector <oferta> a;
	a = srv.ordonaredenumire();
	assert(a.at(0).getdenumire() == "a");
}
void testsortare3()
{
	repoprincipal rep;
	repo2 rep2;
	ofertavalidare val;
	service srv{ rep,rep2 ,val };
	srv.add("b", "b", "c", 100);
	srv.add("a", "b", "c", 10);
	srv.add("d", "d", "a", 1);
	vector <oferta> a;
	a = srv.ordonaretippret();
	assert(a.at(0).getdenumire() == "a");
}
void testdelete()
{
	repoprincipal rep;
	repo2 rep2;
	ofertavalidare val;
	service srv{ rep,rep2 ,val };
	srv.add("a", "a", "a", 100);
	srv.add("b", "b", "b", 10);
	srv.del("b", "b", "b", 10);
	auto ofer = srv.getall();
	assert(ofer.size() == 1);

	srv.add("c", "c", "d", 100);
	srv.add("d", "c", "d", 10);
	srv.del("c", "c", "d", 100);
	ofer = srv.getall();
	assert(ofer.size() == 2);
}
void testadaugaresubmeniu()
{

	repoprincipal rep;
	repo2 rep2;
	ofertavalidare val;
	vector<oferta> a;
	service srv{ rep,rep2 ,val };
	srv.add("a", "a", "a", 100);
	srv.add("b", "b", "b", 10);
	srv.adaugaresubmeniu("a");
	assert(srv.adaugaresubmeniu("a") == -1);
}
void testgoliresubmeniu()
{
	repoprincipal rep;
	repo2 rep2;
	ofertavalidare val;
	service srv{ rep,rep2,val };
	vector<oferta> a;
	srv.adaugaresubmeniu("a");
	srv.goliresubmeniu();
	assert(a.size() == 0);
}
void testgenerarealeator()
{
	repoprincipal rep;
	repo2 rep2;
	ofertavalidare val;
	oferta o{ "a","a","a",100 };
	oferta o1{ "b","a","a",100 };
	rep.adaugare(o);
	rep.adaugare(o1);
	service srv{ rep,rep2,val };
	vector<oferta> a;
	srv.generarealeator1(1);
	a = srv.getall2();
	assert(a.size() == 1);
	srv.generarealeator1(2);
	a = srv.getall2();
	assert(a.size() == 3);
}
void testallprice()
{

	repoprincipal rep;
	repo2 rep2;
	ofertavalidare val;
	oferta o{ "a","a","a",100 };
	oferta o1{ "b","a","a",100 };
	rep.adaugare(o);
	rep.adaugare(o1);
	service srv{ rep,rep2,val };
	assert(srv.allprices() == 200);
}
void testundo()
{
	repoprincipal rep;
	repo2 rep2;
	ofertavalidare val;
	oferta o{ "a","a","a",100 };
	oferta o1{ "b","a","a",100 };
	service srv{ rep,rep2,val };
	srv.add(o.getdenumire(), o.getdestinatie(), o.gettip(), o.getpret());
	srv.add(o1.getdenumire(), o1.getdestinatie(), o1.gettip(), o1.getpret());
	srv.undo();
	vector <oferta> a;
	a = srv.getall();
	assert(a.size() == 1);

	srv.undo();
	a = srv.getall();
	assert(a.size() == 0);
}
void testundo2()
{
	repoprincipal rep;
	repo2 rep2;
	ofertavalidare val;
	oferta o{ "a","a","a",100 };
	oferta o1{ "b","a","a",100 };
	service srv{ rep,rep2,val };
	srv.add(o.getdenumire(), o.getdestinatie(), o.gettip(), o.getpret());
	srv.add(o1.getdenumire(), o1.getdestinatie(), o1.gettip(), o1.getpret());
	srv.del("a", "a", "a", 100);
	srv.undo();
	vector <oferta> a;
	a = srv.getall();
	assert(a.size() == 2);
}

void testExporta() {
	repoprincipal rep;;
	repo2 rep2;
	ofertavalidare val;
	oferta o{ "a","a","a",100 };
	oferta o1{ "b","a","a",100 };
	service srv{ rep,rep2,val };
	srv.adaugaresubmeniu(o.getdenumire());
	srv.adaugaresubmeniu(o1.getdenumire());
	srv.exportacoscvs("testExport.cvs");
	std::ifstream in("testExport.cvs");
	assert(in.is_open());
	int countLines = 0;
	while (!in.eof()) {
		string line;
		in >> line;
		countLines++;
	}
	in.close();
	assert(countLines == 3);//avem o linie pentru fiecare pet + o linie goala
	srv.exportacoshtml("testExport.html");
	in.open("testExport.html");
	assert(in.is_open());
}
