#include "QtGuiApplication1.h"
#include <QtWidgets/QApplication>
#include "QtGuiApplication1.h"
#include <QtWidgets/QApplication>
#include <QtWidgets/qlabel.h>
#include <QtWidgets/qpushbutton.h>
#include <QtWidgets/qboxlayout>
#include <QtWidgets/qlineedit.h>
#include <qtwidgets/qformlayout.h>
#include <QtWidgets/qlistwidget.h>
#include "guiclasa.h"
#include "repository.h"
#include "service.h"
#include "validator.h"
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h> 
int main(int argc, char *argv[])
{
	test_repo();
	testadd();
	testmodificare();
	testcautare();
	testsortare();
	testdelete();
	testsortare2();
	testsortare3();
	testfiltrarepret();
	testfiltrare();
	testadaugaresubmeniu();
	testgoliresubmeniu();
	testgenerarealeator();
	testundo();
	testallprice();
	testundo();
	testundo2();
	testExporta();
	testFileRepo();
	//repofile rep("fisier.txt");
	{repoprincipal rep;
	repo2 rep2;
	ofertavalidare val;
	service srv{ rep,rep2,val };

	QApplication a(argc, argv);
	guiafisareui gui(srv);
	gui.show();
	return a.exec();
	}
	_CrtDumpMemoryLeaks();
	
}
