#pragma once
#include <string>
#include "domain.h"
#include <vector>

using namespace std;
class ofertavalidare
{
public:
	int validare(const oferta& o);
};