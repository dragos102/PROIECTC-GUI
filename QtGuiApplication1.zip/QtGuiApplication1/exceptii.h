#pragma once
#include <fstream>
#include <ostream>

#include <string>
using std::string;
using std::ostream;
class exceptii
{
private:
	string msg;
public:
	exceptii(string m) :msg{ m }
	{

	}
	friend ostream& operator<<(ostream& out, exceptii& ex);
	string get_message()const;
};

